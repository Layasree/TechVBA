﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebAPI_IRCTC_Service.Infrastructure.Abstract;
using WebAPI_IRCTC_Service.Infrastructure.Repository;
using WebAPI_IRCTC_Service.Models;

namespace WebAPI_IRCTC_Service.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class IRCTCServiceController : ControllerBase
    {
        IReservationRepository _repo = new ReservationRepository();
        
        public ResponseInfo GetPNRStatusData(string pnr)
        {
            ResponseInfo resp = null;
            try
            {
                resp = _repo.GetReservationDetail(pnr);               
            }
            catch(Exception ex)
            {
                string err = ex.Message;
            }

            return resp;
        }

    }
}
