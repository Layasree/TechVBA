﻿using WebAPI_IRCTC_Service.Models;

namespace WebAPI_IRCTC_Service.Infrastructure.Abstract
{
    public interface IReservationRepository
    {
        ResponseInfo GetReservationDetail(string pnr);
    }
}
