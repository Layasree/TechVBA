﻿using WebAPI_IRCTC_Service.Infrastructure.Abstract;
using WebAPI_IRCTC_Service.Models;

namespace WebAPI_IRCTC_Service.Infrastructure.Repository
{
    public class ReservationRepository : IReservationRepository
    {
        public ResponseInfo GetReservationDetail(string pnr)
        {
            ResponseInfo resp = new ResponseInfo { ID = 1, PNRNumber = "111", PNRSatus = "Conf", TravelDate = DateTime.Now };

            return resp;
        }
    }
}
