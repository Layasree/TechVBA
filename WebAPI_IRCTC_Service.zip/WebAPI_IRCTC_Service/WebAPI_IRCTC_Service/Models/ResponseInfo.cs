﻿namespace WebAPI_IRCTC_Service.Models
{
    public class ResponseInfo
    {
        public int ID { get; set; }
        public string PNRNumber { get; set; }
        public string PNRSatus { get; set; }

        public DateTime TravelDate { get; set; }
    }
}
